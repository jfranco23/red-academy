/**
 * Supabase Edge Functions para DeveloperData.ai
 *
 * INSTRUCCIONES:
 * 1. Instalar Supabase CLI: npm install -g supabase
 * 2. supabase init
 * 3. Crear las funciones:
 *    supabase functions new create-checkout-session
 *    supabase functions new stripe-webhook
 * 4. Copiar cada función abajo en su archivo correspondiente
 * 5. supabase functions deploy create-checkout-session
 * 6. supabase functions deploy stripe-webhook
 * 7. Configurar secretos:
 *    supabase secrets set STRIPE_SECRET_KEY=sk_live_...
 *    supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_...
 */

// ════════════════════════════════════════════════════════════
// FUNCIÓN 1: create-checkout-session
// Archivo: supabase/functions/create-checkout-session/index.ts
// ════════════════════════════════════════════════════════════
/*
import Stripe from 'https://esm.sh/stripe@13.0.0';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
  apiVersion: '2023-10-16',
});

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });

  const { priceId, userId, email, successUrl, cancelUrl } = await req.json();

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  );

  // Buscar o crear customer en Stripe
  const { data: sub } = await supabase
    .from('subscriptions')
    .select('stripe_customer_id')
    .eq('user_id', userId)
    .single();

  let customerId = sub?.stripe_customer_id;
  if (!customerId) {
    const customer = await stripe.customers.create({ email, metadata: { userId } });
    customerId = customer.id;
    await supabase.from('subscriptions').upsert({
      user_id: userId,
      stripe_customer_id: customerId,
    });
  }

  // Crear sesión de Stripe Checkout
  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    mode: 'subscription',
    payment_method_types: ['card'],
    line_items: [{ price: priceId, quantity: 1 }],
    success_url: successUrl,
    cancel_url: cancelUrl,
    metadata: { userId },
    subscription_data: { metadata: { userId } },
  });

  return new Response(JSON.stringify({ url: session.url }), {
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    },
  });
});
*/

// ════════════════════════════════════════════════════════════
// FUNCIÓN 2: stripe-webhook
// Archivo: supabase/functions/stripe-webhook/index.ts
// ════════════════════════════════════════════════════════════
/*
import Stripe from 'https://esm.sh/stripe@13.0.0';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
  apiVersion: '2023-10-16',
});

Deno.serve(async (req) => {
  const sig = req.headers.get('stripe-signature')!;
  const body = await req.text();
  const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET')!;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, webhookSecret);
  } catch (err) {
    return new Response('Webhook signature failed', { status: 400 });
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  );

  switch (event.type) {
    case 'customer.subscription.created':
    case 'customer.subscription.updated': {
      const subscription = event.data.object as Stripe.Subscription;
      const userId = subscription.metadata.userId;
      const plan = subscription.items.data[0].price.lookup_key?.includes('annual') ? 'pro_annual' : 'pro';

      await supabase.from('subscriptions').upsert({
        user_id: userId,
        stripe_subscription_id: subscription.id,
        stripe_customer_id: subscription.customer as string,
        plan,
        status: subscription.status === 'active' ? 'active' : 'inactive',
        current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
        updated_at: new Date().toISOString(),
      }, { onConflict: 'user_id' });
      break;
    }

    case 'customer.subscription.deleted': {
      const subscription = event.data.object as Stripe.Subscription;
      const userId = subscription.metadata.userId;
      await supabase.from('subscriptions').upsert({
        user_id: userId,
        plan: 'explorer',
        status: 'canceled',
        updated_at: new Date().toISOString(),
      }, { onConflict: 'user_id' });
      break;
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object as Stripe.Invoice;
      const subscription = await stripe.subscriptions.retrieve(invoice.subscription as string);
      const userId = subscription.metadata.userId;
      await supabase.from('subscriptions').upsert({
        user_id: userId,
        status: 'past_due',
        updated_at: new Date().toISOString(),
      }, { onConflict: 'user_id' });
      break;
    }
  }

  return new Response(JSON.stringify({ received: true }), {
    headers: { 'Content-Type': 'application/json' },
  });
});
*/

// ════════════════════════════════════════════════════════════
// FUNCIÓN 3: create-portal-session
// Archivo: supabase/functions/create-portal-session/index.ts
// ════════════════════════════════════════════════════════════
/*
import Stripe from 'https://esm.sh/stripe@13.0.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
  apiVersion: '2023-10-16',
});

Deno.serve(async (req) => {
  const { customerId, returnUrl } = await req.json();
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: returnUrl,
  });
  return new Response(JSON.stringify({ url: session.url }), {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  });
});
*/

console.log('Supabase Edge Functions — ver comentarios en este archivo para el código completo.');
