/**
 * Netlify Function: create-order
 * Crea una orden de PayPal en el servidor
 *
 * Variables de entorno requeridas en Netlify:
 * PAYPAL_CLIENT_ID  = TU_CLIENT_ID_PAYPAL
 * PAYPAL_SECRET     = TU_SECRET_PAYPAL
 * PAYPAL_MODE       = sandbox (pruebas) | live (producción)
 */

const PAYPAL_BASE = {
  sandbox: 'https://api-m.sandbox.paypal.com',
  live:    'https://api-m.paypal.com',
};

async function getAccessToken() {
  const mode   = process.env.PAYPAL_MODE || 'sandbox';
  const base   = PAYPAL_BASE[mode];
  const creds  = Buffer.from(
    `${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_SECRET}`
  ).toString('base64');

  const res = await fetch(`${base}/v1/oauth2/token`, {
    method:  'POST',
    headers: {
      Authorization: `Basic ${creds}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });

  const data = await res.json();
  return data.access_token;
}

exports.handler = async (event) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const { productId, productName, amount } = JSON.parse(event.body);

    if (!amount || amount <= 0) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Monto inválido' }) };
    }

    const accessToken = await getAccessToken();
    const mode        = process.env.PAYPAL_MODE || 'sandbox';
    const base        = PAYPAL_BASE[mode];

    const res = await fetch(`${base}/v2/checkout/orders`, {
      method:  'POST',
      headers: {
        Authorization:               `Bearer ${accessToken}`,
        'Content-Type':              'application/json',
        'PayPal-Request-Id':         `REDA-${productId}-${Date.now()}`,
        'Prefer':                    'return=representation',
      },
      body: JSON.stringify({
        intent: 'CAPTURE',
        purchase_units: [{
          reference_id: productId,
          description:  productName,
          amount: {
            currency_code: 'USD',
            value:         String(Number(amount).toFixed(2)),
          },
        }],
        payment_source: {
          paypal: {
            experience_context: {
              brand_name:            'RED ACADEMY',
              landing_page:          'NO_PREFERENCE',
              shipping_preference:   'NO_SHIPPING',
              user_action:           'PAY_NOW',
              return_url:            `${process.env.URL || 'https://redevacademy.com'}/`,
              cancel_url:            `${process.env.URL || 'https://redevacademy.com'}/`,
            },
          },
        },
      }),
    });

    const order = await res.json();

    if (!res.ok) {
      console.error('PayPal create-order error:', order);
      return {
        statusCode: 422,
        headers,
        body: JSON.stringify({ error: order.message || 'Error creando orden' }),
      };
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ orderID: order.id }),
    };

  } catch (err) {
    console.error('create-order exception:', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Error interno del servidor' }),
    };
  }
};
