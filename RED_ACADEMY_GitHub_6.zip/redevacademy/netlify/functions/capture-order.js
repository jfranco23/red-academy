/**
 * Netlify Function: capture-order
 * 1. Captura el pago de PayPal
 * 2. Envía email con el link de descarga del PDF
 *
 * Variables de entorno requeridas en Netlify:
 * PAYPAL_CLIENT_ID   = TU_CLIENT_ID_PAYPAL
 * PAYPAL_SECRET      = TU_SECRET_PAYPAL
 * PAYPAL_MODE        = sandbox | live
 * SENDGRID_API_KEY   = TU_SENDGRID_API_KEY (gratis: 100 emails/día)
 * FROM_EMAIL         = redacademy@gmail.com (tu email remitente)
 * FROM_NAME          = RED ACADEMY
 */

const PAYPAL_BASE = {
  sandbox: 'https://api-m.sandbox.paypal.com',
  live:    'https://api-m.paypal.com',
};

async function getAccessToken() {
  const mode  = process.env.PAYPAL_MODE || 'sandbox';
  const base  = PAYPAL_BASE[mode];
  const creds = Buffer.from(
    `${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_SECRET}`
  ).toString('base64');

  const res = await fetch(`${base}/v1/oauth2/token`, {
    method:  'POST',
    headers: { Authorization: `Basic ${creds}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=client_credentials',
  });
  const data = await res.json();
  return data.access_token;
}

async function capturePayPalOrder(orderID) {
  const accessToken = await getAccessToken();
  const mode        = process.env.PAYPAL_MODE || 'sandbox';
  const base        = PAYPAL_BASE[mode];

  const res = await fetch(`${base}/v2/checkout/orders/${orderID}/capture`, {
    method:  'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
  });

  const data = await res.json();
  return { ok: res.ok, data };
}

async function sendEmail({ to, productName, driveLink, amount }) {
  const SENDGRID_KEY = process.env.SENDGRID_API_KEY;
  const fromEmail    = process.env.FROM_EMAIL  || 'hello@redevacademy.com';
  const fromName     = process.env.FROM_NAME   || 'RED ACADEMY';

  if (!SENDGRID_KEY) {
    console.warn('SENDGRID_API_KEY no configurado — email no enviado');
    return true; // Don't fail the purchase for missing email
  }

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { background: #080808; color: #fff; font-family: 'Georgia', serif; margin: 0; padding: 0; }
    .container { max-width: 580px; margin: 0 auto; padding: 40px 20px; }
    .logo { font-size: 22px; font-weight: 300; letter-spacing: .1em; color: #C9943A; margin-bottom: 32px; }
    .logo strong { color: #fff; font-weight: 600; }
    h1 { font-size: 32px; font-weight: 300; color: #fff; margin-bottom: 8px; font-style: italic; }
    .sub { font-size: 15px; color: rgba(255,255,255,0.5); margin-bottom: 32px; line-height: 1.6; }
    .product-box {
      background: rgba(201,148,58,0.08);
      border: 1px solid rgba(201,148,58,0.3);
      padding: 24px;
      margin-bottom: 28px;
    }
    .product-label { font-size: 10px; letter-spacing: .18em; text-transform: uppercase; color: #C9943A; margin-bottom: 6px; }
    .product-name { font-size: 20px; color: #fff; margin-bottom: 4px; }
    .product-price { font-size: 28px; font-weight: 300; color: #C9943A; font-style: italic; }
    .download-btn {
      display: block;
      background: #C9943A;
      color: #fff !important;
      text-decoration: none;
      padding: 16px 32px;
      text-align: center;
      font-size: 14px;
      font-weight: 600;
      letter-spacing: .08em;
      text-transform: uppercase;
      margin-bottom: 24px;
    }
    .note { font-size: 12px; color: rgba(255,255,255,0.3); line-height: 1.7; }
    .divider { border: none; border-top: 1px solid rgba(255,255,255,0.08); margin: 28px 0; }
    .footer { font-size: 11px; color: rgba(255,255,255,0.2); line-height: 1.7; }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo"><strong>RED</strong> ACADEMY</div>
    <h1>Tu compra está lista.</h1>
    <p class="sub">
      Muchas gracias por tu compra. Haz clic en el botón de abajo para descargar
      tu producto inmediatamente. El link estará disponible en todo momento.
    </p>

    <div class="product-box">
      <div class="product-label">Tu producto</div>
      <div class="product-name">${productName}</div>
      <div class="product-price">$${amount} USD</div>
    </div>

    <a href="${driveLink}" class="download-btn">
      ⬇ Descargar ahora — ${productName}
    </a>

    <p class="note">
      ¿Problemas con la descarga? Responde este email y te ayudamos de inmediato.<br>
      El link de descarga no expira — puedes usarlo en cualquier momento.<br>
      Guarda este email para futuras referencias.
    </p>

    <hr class="divider">
    <div class="footer">
      RED ACADEMY · Real Estate Developer Academy · Bocas del Toro, Panamá<br>
      redevacademy.com · Para soporte: hello@redevacademy.com<br><br>
      Si no compraste este producto, por favor ignora este email.
    </div>
  </div>
</body>
</html>`;

  const res = await fetch('https://api.sendgrid.com/v3/mail/send', {
    method:  'POST',
    headers: {
      Authorization:  `Bearer ${SENDGRID_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      personalizations: [{ to: [{ email: to }] }],
      from: { email: fromEmail, name: fromName },
      subject: `✓ Tu PDF: ${productName} — RED ACADEMY`,
      content: [
        { type: 'text/html', value: html },
        {
          type: 'text/plain',
          value: `RED ACADEMY — Tu compra: ${productName}\n\nDescarga tu PDF: ${driveLink}\n\n¡Gracias por tu compra!\nREDA · redevacademy.com`,
        },
      ],
    }),
  });

  return res.status >= 200 && res.status < 300;
}

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { orderID, email, productId, driveLink, productName } = JSON.parse(event.body);

    // 1. Capture payment
    const { ok, data: capture } = await capturePayPalOrder(orderID);

    if (!ok) {
      console.error('Capture failed:', capture);
      return {
        statusCode: 422,
        headers,
        body: JSON.stringify({
          success: false,
          message: capture.details?.[0]?.description || 'Error al capturar el pago',
        }),
      };
    }

    const amount = capture.purchase_units?.[0]?.payments?.captures?.[0]?.amount?.value || '0';

    // 2. Send email with PDF download link
    await sendEmail({ to: email, productName, driveLink, amount });

    // 3. Log the sale (optional — just console for now)
    console.log('SALE:', {
      timestamp:   new Date().toISOString(),
      email,
      productId,
      productName,
      amount,
      paypalOrderId: orderID,
      captureId:   capture.purchase_units?.[0]?.payments?.captures?.[0]?.id,
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success:   true,
        amount,
        driveLink,
        message:   'Pago completado. Email enviado.',
      }),
    };

  } catch (err) {
    console.error('capture-order exception:', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ success: false, message: 'Error interno del servidor' }),
    };
  }
};
