#!/bin/bash
# ══════════════════════════════════════════════════════════════
# RED ACADEMY — Deploy automático a GitHub + GitHub Pages
# Ejecutar en Mac/Linux: bash deploy.sh
# ══════════════════════════════════════════════════════════════

set -e

TOKEN="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"
REPO="redevacademy"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   RED ACADEMY — Deploy a GitHub Pages    ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── 1. Obtener username ────────────────────────────────────────
echo "→ Verificando credenciales GitHub..."
USER=$(curl -s \
  -H "Authorization: token $TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  https://api.github.com/user | python3 -c "import sys,json; print(json.load(sys.stdin)['login'])")

echo "  ✓ Usuario: $USER"
echo ""

# ── 2. Crear repositorio ───────────────────────────────────────
echo "→ Creando repositorio '$REPO'..."
CREATE=$(curl -s -o /dev/null -w "%{http_code}" \
  -X POST \
  -H "Authorization: token $TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  https://api.github.com/user/repos \
  -d "{\"name\":\"$REPO\",\"description\":\"RED ACADEMY — Real Estate Developer Academy · redevacademy.com\",\"private\":false,\"auto_init\":false}")

if [ "$CREATE" = "201" ]; then
  echo "  ✓ Repositorio creado: https://github.com/$USER/$REPO"
elif [ "$CREATE" = "422" ]; then
  echo "  ℹ  El repositorio ya existe — usando el existente"
else
  echo "  ✗ Error creando repositorio (HTTP $CREATE)"
  exit 1
fi
echo ""

# ── 3. Inicializar git y subir archivos ────────────────────────
echo "→ Inicializando repositorio git local..."

# Verificar que estamos en la carpeta correcta
if [ ! -f "index.html" ]; then
  echo "  ✗ ERROR: No encuentro index.html"
  echo "    Asegúrate de ejecutar este script DENTRO de la carpeta redevacademy/"
  echo "    Ejemplo: cd redevacademy && bash deploy.sh"
  exit 1
fi

git init -q
git config user.email "redacademy@deploy.com"
git config user.name "RED ACADEMY"

# Agregar todos los archivos
git add .
git commit -q -m "🚀 RED ACADEMY v1.0 — Deploy inicial completo

- Home / Landing page
- Catálogo de productos (6 productos + bundle)
- Sales page Curso REDM
- Portal de estudiantes con laboratorios integrados
- Panel de administración
- 5 páginas individuales de productos
- 5 simuladores interactivos (Factibilidad, Presupuesto, Financiamiento, STR, Lab)
- README.md con instrucciones completas
- netlify.toml para deploy en Netlify"

echo "  ✓ Archivos commiteados"
echo ""

# ── 4. Push a GitHub ───────────────────────────────────────────
echo "→ Subiendo archivos a GitHub..."

REMOTE="https://$TOKEN@github.com/$USER/$REPO.git"
git remote add origin "$REMOTE" 2>/dev/null || git remote set-url origin "$REMOTE"
git branch -M main
git push -u origin main -q

echo "  ✓ Archivos subidos exitosamente"
echo ""

# ── 5. Activar GitHub Pages ────────────────────────────────────
echo "→ Activando GitHub Pages..."

PAGES=$(curl -s -o /dev/null -w "%{http_code}" \
  -X POST \
  -H "Authorization: token $TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  https://api.github.com/repos/$USER/$REPO/pages \
  -d '{"source":{"branch":"main","path":"/"}}')

if [ "$PAGES" = "201" ] || [ "$PAGES" = "409" ]; then
  echo "  ✓ GitHub Pages activado"
else
  echo "  ℹ  GitHub Pages: HTTP $PAGES (puede que necesites activarlo manualmente)"
fi
echo ""

# ── 6. Resultado final ─────────────────────────────────────────
echo "╔══════════════════════════════════════════════════════════╗"
echo "║              ✅  DEPLOY COMPLETADO                       ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║                                                          ║"
echo "║  Repositorio:  https://github.com/$USER/$REPO"
echo "║  Sitio web:    https://$USER.github.io/$REPO/"
echo "║                                                          ║"
echo "║  ⏳ GitHub Pages puede tardar 2-5 minutos en activarse  ║"
echo "║                                                          ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "⚠  IMPORTANTE: Revoca el token usado en este script:"
echo "   → https://github.com/settings/tokens"
echo "   Selecciona el token 'redevacademy-deploy' y click 'Delete'"
echo ""
