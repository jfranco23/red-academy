/**
 * RED ACADEMY — Catálogo de Productos
 * Llena los driveLink con las URLs reales de Google Drive
 * Cada URL debe ser: Compartir → "Cualquiera con el link" → Copiar link
 */

const PRODUCTS = {
  'factibilidad': {
    id:    'ebook-01-factibilidad',
    page:  'producto-factibilidad.html',
    price: 47,
    cover: { color: 'linear-gradient(145deg,#0E1628,#070D1A)', text: '#A8CDEF' },
    name: {
      es: 'Análisis de Factibilidad Inmobiliaria',
      en: 'Real Estate Feasibility Analysis',
      pt: 'Análise de Viabilidade Imobiliária',
    },
    desc: {
      es: '142 páginas · PDF + Plantillas Excel · Metodología completa',
      en: '142 pages · PDF + Excel Templates · Complete methodology',
      pt: '142 páginas · PDF + Modelos Excel · Metodologia completa',
    },
    // ⬇ LLENA ESTO: Google Drive → Compartir → Cualquiera con el link → Copiar
    driveLink: 'https://drive.google.com/file/d/TU_FILE_ID_01/view?usp=sharing',
  },

  'presupuesto': {
    id:    'ebook-02-presupuesto',
    page:  'producto-presupuesto.html',
    price: 39,
    cover: { color: 'linear-gradient(145deg,#14100A,#0A0806)', text: '#F0C060' },
    name: {
      es: 'Presupuesto de Construcción Maestro',
      en: 'Master Construction Budget',
      pt: 'Orçamento de Construção Mestre',
    },
    desc: {
      es: '14 capítulos · 120+ ítems · Benchmarks Panamá',
      en: '14 chapters · 120+ items · Panama benchmarks',
      pt: '14 capítulos · 120+ itens · Benchmarks Panamá',
    },
    driveLink: 'https://drive.google.com/file/d/TU_FILE_ID_02/view?usp=sharing',
  },

  'financiamiento': {
    id:    'ebook-03-financiamiento',
    page:  'producto-financiamiento.html',
    price: 49,
    cover: { color: 'linear-gradient(145deg,#0E1A14,#070E0A)', text: '#96D9B8' },
    name: {
      es: 'Financiamiento Bancario para Desarrolladores',
      en: 'Bank Financing for Developers',
      pt: 'Financiamento Bancário para Desenvolvedores',
    },
    desc: {
      es: '10 bancos de Panamá · Tasas Q4 2025 · PDF',
      en: '10 Panama banks · Q4 2025 rates · PDF',
      pt: '10 bancos do Panamá · Taxas Q4 2025 · PDF',
    },
    driveLink: 'https://drive.google.com/file/d/TU_FILE_ID_03/view?usp=sharing',
  },

  'str': {
    id:    'ebook-04-str',
    page:  'producto-str.html',
    price: 55,
    cover: { color: 'linear-gradient(145deg,#16100E,#0C0806)', text: '#E8AB92' },
    name: {
      es: 'Modelo Financiero de Proyectos STR',
      en: 'STR Project Financial Model',
      pt: 'Modelo Financeiro de Projetos STR',
    },
    desc: {
      es: 'Airbnb · VRBO · Proyección 5 años · PDF + Excel',
      en: 'Airbnb · VRBO · 5-year projection · PDF + Excel',
      pt: 'Airbnb · VRBO · Projeção 5 anos · PDF + Excel',
    },
    driveLink: 'https://drive.google.com/file/d/TU_FILE_ID_04/view?usp=sharing',
  },

  'contratos': {
    id:    'ebook-05-contratos',
    page:  'producto-contratos.html',
    price: 69,
    cover: { color: 'linear-gradient(145deg,#140E18,#0A080E)', text: '#C8ADEB' },
    name: {
      es: 'Pack de Contratos para Desarrolladores',
      en: 'Developer Contracts Pack',
      pt: 'Pack de Contratos para Desenvolvedores',
    },
    desc: {
      es: '16 documentos Word · Panamá 2025',
      en: '16 Word documents · Panama 2025',
      pt: '16 documentos Word · Panamá 2025',
    },
    driveLink: 'https://drive.google.com/file/d/TU_FILE_ID_05/view?usp=sharing',
  },

  'bundle': {
    id:    'bundle-todos-los-ebooks',
    page:  'catalogo.html',
    price: 199,
    cover: { color: 'linear-gradient(145deg,#0A0C08,#060807)', text: '#F0C060' },
    name: {
      es: 'Bundle — Todos los Ebooks',
      en: 'Bundle — All Ebooks',
      pt: 'Bundle — Todos os Ebooks',
    },
    desc: {
      es: '5 ebooks completos · $259 de valor · Ahorra $60',
      en: '5 complete ebooks · $259 value · Save $60',
      pt: '5 ebooks completos · $259 em valor · Economize $60',
    },
    driveLink: 'https://drive.google.com/drive/folders/TU_FOLDER_ID/view?usp=sharing',
  },
};

// ── HELPER: Get product by key ──────────────────────────────
function getProduct(key) {
  return PRODUCTS[key] || null;
}

// ── HELPER: Detect current product from URL ─────────────────
function detectProduct() {
  const url = window.location.pathname;
  const map = {
    'factibilidad':  'factibilidad',
    'presupuesto':   'presupuesto',
    'financiamiento':'financiamiento',
    'str':           'str',
    'contratos':     'contratos',
  };
  for (const [slug, key] of Object.entries(map)) {
    if (url.includes(slug)) return key;
  }
  return null;
}

window.PRODUCTS    = PRODUCTS;
window.getProduct  = getProduct;
window.detectProduct = detectProduct;
