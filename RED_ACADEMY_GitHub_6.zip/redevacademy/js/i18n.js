/**
 * RED ACADEMY — Sistema de traducción i18n
 * Idiomas: Español (es) · English (en) · Português (pt)
 * Uso: <span data-i18n="hero.title"></span>
 */

const TRANSLATIONS = {

  /* ─────────────────────────────────────────────
     ESPAÑOL (default)
  ───────────────────────────────────────────── */
  es: {
    lang: 'es',
    dir: 'ltr',
    meta: {
      title: 'RED ACADEMY — Real Estate Developer Academy · Panamá & LATAM',
      description: 'La plataforma de conocimiento especializado para desarrolladores inmobiliarios. Ebooks, simuladores y el Curso REDM para Panamá y LATAM.',
    },

    nav: {
      products:  'Productos',
      curriculum:'Temario',
      founder:   'Fundador',
      testimonials:'Testimonios',
      tools:     'Herramientas',
      cta:       'Ver Catálogo',
      signin:    'Ingresar',
    },

    hero: {
      eyebrow:   'Real Estate Developer Academy',
      badge:     '5 ebooks + curso + simuladores',
      title1:    'El conocimiento',
      title2:    'que construye',
      title3:    'proyectos',
      titleEm:   'rentables',
      sub:       'Desde el análisis de factibilidad hasta el cierre de ventas. Metodología real aplicada en desarrollos de Panamá y LATAM — en ebooks profesionales, plantillas y simuladores interactivos.',
      pill1:     'Factibilidad',
      pill2:     'Presupuesto',
      pill3:     'Financiamiento',
      pill4:     'STR · Airbnb',
      pill5:     'Contratos',
      pill6:     'Curso REDM',
      cta1:      'Ver todos los ebooks',
      cta2:      'Curso REDM →',
      trust1:    'PDF + Excel incluidos',
      trust2:    'Acceso inmediato',
      trust3:    'Datos reales de Panamá',
    },

    stats: {
      s1num:   '+500', s1label: 'Estudiantes Activos',
      s2num:   '12',   s2label: 'Ebooks & Cursos',
      s3num:   '$50M+',s3label: 'En Proyectos Desarrollados',
      s4num:   '8',    s4label: 'Países con Alumnos',
    },

    manifesto: {
      label:   'Nuestra Misión',
      quote:   '"El desarrollador que entiende los números, controla el proyecto."',
      p1:      'La mayoría de los proyectos inmobiliarios fracasan no por falta de terrenos o dinero, sino por falta de estructura. Un mal análisis de costo, una proyección financiera incompleta o una mala negociación pueden consumir meses de trabajo.',
      p2:      'REDA nació para cambiar eso. Condensamos más de una década de experiencia real en desarrollos habitacionales, villas de lujo y proyectos mixtos en recursos accionables que puedes aplicar desde hoy.',
      p3:      'No teoría. No casos genéricos. Metodología probada en el campo.',
    },

    pain: {
      label:   'Por qué REDA existe',
      title1:  'Los errores que',
      titleEm: 'cuestan millones',
      e1title: 'Análisis financiero deficiente',
      e1desc:  'Proyectos que arrancan sin un modelo de flujo de caja sólido terminan descapitalizados antes de la etapa de ventas.',
      e2title: 'Costos de construcción descontrolados',
      e2desc:  'El sobrecosto es la variable más peligrosa en cualquier desarrollo. Aprende a estructurar presupuestos con contingencias reales.',
      e3title: 'Estrategia comercial tardía',
      e3desc:  'Empezar a vender cuando el proyecto ya está construido es el error clásico. Domina la comercialización temprana.',
      e4title: 'Estructura legal vulnerable',
      e4desc:  'Proyectos sin una S.A. patrimonial, sin contratos sólidos o con títulos pendientes de registro son bombas de tiempo.',
      e5title: 'Sin acceso a financiamiento',
      e5desc:  'Los bancos financian proyectos bien documentados. Aprende a armar expedientes bancarios y valuaciones.',
      e6title: 'Rentabilidad no cuantificada',
      e6desc:  'Vender todo y no saber cuánto ganaste. La contabilidad de proyecto y el cálculo correcto del ROI son habilidades críticas.',
    },

    products: {
      label:   'Recursos',
      title1:  'Todo lo que necesitas',
      titleEm: 'para desarrollar',
      p1name:  'Análisis de Factibilidad Inmobiliaria',
      p1desc:  'Metodología completa para evaluar si un proyecto vale la pena antes de invertir un solo dólar. Incluye plantillas en Excel.',
      p1sub:   'PDF + Excel · 142 págs.',
      p2name:  'Presupuesto de Construcción Maestro',
      p2desc:  'Estructura capítulo por capítulo un presupuesto real con materiales, mano de obra, imprevistos y contingencias.',
      p2sub:   '14 capítulos · 120+ ítems',
      p3name:  'Financiamiento Bancario para Desarrolladores',
      p3desc:  'Cómo armar el expediente perfecto para crédito hipotecario o línea rotativa. Documentos, ratios y estrategias.',
      p3sub:   '10 bancos · Panamá 2025',
      p4name:  'Modelo Financiero de Proyectos STR',
      p4desc:  'Proyección de ingresos, ocupación, gastos operativos y ROI para villas y propiedades de renta corta en mercados turísticos.',
      p4sub:   'Airbnb · VRBO · 5 años',
      p5name:  'Pack de Contratos para Desarrolladores',
      p5desc:  'Contratos de promesa de compraventa, acuerdos con contratistas, separaciones y protocolos de entrega listos para usar.',
      p5sub:   '16 documentos · Word',
      p6name:  'Real Estate Developer Master – REDM',
      p6desc:  'El programa completo. Desde la selección del terreno hasta el cierre de ventas. 8 módulos con casos reales de Panamá y LATAM.',
      p6sub:   '8 módulos · Curso online',
      cta:     'Obtener',
      ctaCourse: 'Ver Programa',
      tagEbook: 'Ebook',
      tagTemplate: 'Plantilla',
      tagCourse: 'Curso Online',
      tagBestseller: 'Bestseller',
      tagNew: 'Nuevo',
    },

    curriculum: {
      label:   'Temario REDM',
      title1:  'Construye tu',
      titleEm: 'primer desarrollo',
      sub:     'Un sistema completo de 8 módulos que cubre todo el proceso de desarrollo inmobiliario desde cero hasta la entrega.',
      m1: 'Módulo 1 · Fundamentos y Selección de Terreno',
      m2: 'Módulo 2 · Análisis de Factibilidad Avanzado',
      m3: 'Módulo 3 · Diseño y Permisos',
      m4: 'Módulo 4 · Presupuesto y Control de Costos',
      m5: 'Módulo 5 · Financiamiento Bancario',
      m6: 'Módulo 6 · Comercialización y Preventas',
      m7: 'Módulo 7 · Ejecución y Gestión de Obra',
      m8: 'Módulo 8 · Cierre, Entrega y Rentabilidad Final',
      bonus: 'Bonus: Plantillas Excel, contratos y simuladores',
      cta: 'Ver Programa Completo →',
    },

    founder: {
      label:   'El Fundador',
      name:    'Jorge Franco',
      role:    'CEO · Grupo Franco Carrera S.A.',
      bio1:    'Con más de una década desarrollando proyectos residenciales, villas de lujo y desarrollos mixtos en Bocas del Toro y Chiriquí, Jorge creó REDA para llevar la metodología real del campo al aula.',
      bio2:    'Más de $2.3M en ventas residenciales completadas. Fundador de Franco Inmobiliaria Panamá y co-fundador de APROBOCASDELTORO, la asociación cívica de desarrollo provincial.',
      bio3:    '"Aprendí los errores más caros en mis propios proyectos. REDA existe para que tú no tengas que pagarlos."',
      cta:     'Ver Portafolio de Proyectos →',
    },

    testimonials: {
      label:   'Testimonios',
      title1:  'Lo que dicen',
      titleEm: 'nuestros estudiantes',
      t1:      '"Apliqué el modelo de factibilidad del Módulo 2 en mi primer proyecto y el banco aprobó el crédito en la primera presentación. No puedo creer la diferencia que hace tener los números bien estructurados."',
      t1name:  'Carlos Mendoza',
      t1role:  'Desarrollador · Ciudad de Panamá',
      t2:      '"El ebook de presupuesto me ahorró meses de trabajo y me salvó de un contratista que me quería cobrar el doble. Ahora sé exactamente qué preguntar y qué esperar."',
      t2name:  'Daniela Ríos',
      t2role:  'Inversionista · Chiriquí',
      t3:      '"Empecé sin saber nada de desarrollo inmobiliario. Hoy estoy cerrando mi primer proyecto de 8 unidades en Colón. REDA fue la diferencia entre seguir soñando y realmente hacerlo."',
      t3name:  'Miguel Torres',
      t3role:  'Primer desarrollo · Colón',
    },

    cta: {
      label:   'Ideas que te hacen mejor desarrollador',
      sub:     'Cada semana: análisis de mercado, estrategias financieras, casos reales y recursos exclusivos para suscriptores.',
      placeholder: 'Tu correo electrónico',
      btn:     'Suscribirme',
      trust:   'Sin spam. Solo valor real. Cancelación inmediata.',
    },

    footer: {
      tagline:    'La plataforma de conocimiento para desarrolladores e inversores inmobiliarios que quieren construir con inteligencia financiera y estructura sólida.',
      products:   'Productos',
      ebooks:     'Ebooks',
      course:     'Curso REDM',
      excel:      'Plantillas Excel',
      contracts:  'Pack de Contratos',
      mentoring:  'Mentorías',
      academy:    'Academia',
      about:      'Sobre REDA',
      founder:    'El fundador',
      blog:       'Blog',
      cases:      'Casos de estudio',
      podcast:    'Podcast',
      support:    'Soporte',
      faq:        'Preguntas frecuentes',
      contact:    'Contacto',
      privacy:    'Política de privacidad',
      terms:      'Términos de uso',
      refund:     'Devoluciones',
      copy:       '© 2025 Real Estate Developer Academy · redevacademy.com',
      designed:   'Diseñado para desarrolladores que construyen en serio.',
    },
  },

  /* ─────────────────────────────────────────────
     ENGLISH
  ───────────────────────────────────────────── */
  en: {
    lang: 'en',
    dir: 'ltr',
    meta: {
      title: 'RED ACADEMY — Real Estate Developer Academy · Panama & LATAM',
      description: 'Specialized knowledge platform for real estate developers. Ebooks, simulators and the REDM Course for Panama and Latin America.',
    },

    nav: {
      products:  'Products',
      curriculum:'Curriculum',
      founder:   'Founder',
      testimonials:'Testimonials',
      tools:     'Tools',
      cta:       'View Catalog',
      signin:    'Sign in',
    },

    hero: {
      eyebrow:   'Real Estate Developer Academy',
      badge:     '5 ebooks + course + simulators',
      title1:    'The knowledge',
      title2:    'that builds',
      title3:    'profitable',
      titleEm:   'projects',
      sub:       'From feasibility analysis to sales closing. Real methodology applied in Panama and LATAM developments — in professional ebooks, templates and interactive simulators.',
      pill1:     'Feasibility',
      pill2:     'Budget',
      pill3:     'Financing',
      pill4:     'STR · Airbnb',
      pill5:     'Contracts',
      pill6:     'REDM Course',
      cta1:      'View all ebooks',
      cta2:      'REDM Course →',
      trust1:    'PDF + Excel included',
      trust2:    'Immediate access',
      trust3:    'Real Panama market data',
    },

    stats: {
      s1num:   '+500', s1label: 'Active Students',
      s2num:   '12',   s2label: 'Ebooks & Courses',
      s3num:   '$50M+',s3label: 'In Developed Projects',
      s4num:   '8',    s4label: 'Countries with Students',
    },

    manifesto: {
      label:   'Our Mission',
      quote:   '"The developer who understands the numbers, controls the project."',
      p1:      'Most real estate projects fail not for lack of land or money, but for lack of structure. A poor cost analysis, an incomplete financial projection or a bad negotiation can consume months of work.',
      p2:      'REDA was born to change that. We condense more than a decade of real experience in residential developments, luxury villas and mixed projects into actionable resources you can apply starting today.',
      p3:      'No theory. No generic cases. Methodology proven in the field.',
    },

    pain: {
      label:   'Why REDA exists',
      title1:  'The mistakes that',
      titleEm: 'cost millions',
      e1title: 'Poor financial analysis',
      e1desc:  'Projects that start without a solid cash flow model end up undercapitalized before the sales stage.',
      e2title: 'Uncontrolled construction costs',
      e2desc:  'Cost overruns are the most dangerous variable in any development. Learn to structure budgets with real contingencies.',
      e3title: 'Late commercial strategy',
      e3desc:  'Starting to sell when the project is already built is the classic mistake. Master early commercialization.',
      e4title: 'Vulnerable legal structure',
      e4desc:  'Projects without a holding company, solid contracts or pending title registrations are ticking time bombs.',
      e5title: 'No access to financing',
      e5desc:  'Banks finance well-documented projects. Learn to prepare banking files and valuations.',
      e6title: 'Unquantified profitability',
      e6desc:  'Selling everything and not knowing how much you made. Project accounting and correct ROI calculation are critical skills.',
    },

    products: {
      label:   'Resources',
      title1:  'Everything you need',
      titleEm: 'to develop',
      p1name:  'Real Estate Feasibility Analysis',
      p1desc:  'Complete methodology to evaluate whether a project is worthwhile before investing a single dollar. Includes Excel templates.',
      p1sub:   'PDF + Excel · 142 pages',
      p2name:  'Master Construction Budget',
      p2desc:  'Structure a real budget chapter by chapter with materials, labor, contingencies and unexpected costs.',
      p2sub:   '14 chapters · 120+ items',
      p3name:  'Bank Financing for Developers',
      p3desc:  'How to assemble the perfect file for mortgage credit or revolving line. Documents, ratios and strategies.',
      p3sub:   '10 banks · Panama 2025',
      p4name:  'STR Project Financial Model',
      p4desc:  'Revenue projection, occupancy, operating costs and ROI for villas and short-term rental properties in tourist markets.',
      p4sub:   'Airbnb · VRBO · 5 years',
      p5name:  'Contracts Pack for Developers',
      p5desc:  'Purchase promise contracts, contractor agreements, reservations and delivery protocols ready to use.',
      p5sub:   '16 documents · Word',
      p6name:  'Real Estate Developer Master – REDM',
      p6desc:  'The complete program. From land selection to sales closing. 8 modules with real cases from Panama and LATAM.',
      p6sub:   '8 modules · Online course',
      cta:     'Get it',
      ctaCourse: 'View Program',
      tagEbook: 'Ebook',
      tagTemplate: 'Template',
      tagCourse: 'Online Course',
      tagBestseller: 'Bestseller',
      tagNew: 'New',
    },

    curriculum: {
      label:   'REDM Curriculum',
      title1:  'Build your',
      titleEm: 'first development',
      sub:     'A complete 8-module system covering the entire real estate development process from scratch to delivery.',
      m1: 'Module 1 · Fundamentals and Land Selection',
      m2: 'Module 2 · Advanced Feasibility Analysis',
      m3: 'Module 3 · Design and Permits',
      m4: 'Module 4 · Budget and Cost Control',
      m5: 'Module 5 · Bank Financing',
      m6: 'Module 6 · Marketing and Pre-sales',
      m7: 'Module 7 · Construction Execution and Management',
      m8: 'Module 8 · Closing, Delivery and Final Profitability',
      bonus: 'Bonus: Excel templates, contracts and simulators',
      cta: 'View Full Program →',
    },

    founder: {
      label:   'The Founder',
      name:    'Jorge Franco',
      role:    'CEO · Grupo Franco Carrera S.A.',
      bio1:    'With over a decade developing residential projects, luxury villas and mixed developments in Bocas del Toro and Chiriquí, Jorge created REDA to bring real field methodology to the classroom.',
      bio2:    'Over $2.3M in completed residential sales. Founder of Franco Inmobiliaria Panama and co-founder of APROBOCASDELTORO, the provincial civic development association.',
      bio3:    '"I learned the most expensive mistakes in my own projects. REDA exists so you don\'t have to pay for them."',
      cta:     'View Project Portfolio →',
    },

    testimonials: {
      label:   'Testimonials',
      title1:  'What our',
      titleEm: 'students say',
      t1:      '"I applied the feasibility model from Module 2 to my first project and the bank approved the credit in the first presentation. I can\'t believe the difference that having well-structured numbers makes."',
      t1name:  'Carlos Mendoza',
      t1role:  'Developer · Panama City',
      t2:      '"The budget ebook saved me months of work and saved me from a contractor who wanted to charge me double. Now I know exactly what to ask and what to expect."',
      t2name:  'Daniela Ríos',
      t2role:  'Investor · Chiriquí',
      t3:      '"I started knowing nothing about real estate development. Today I\'m closing my first 8-unit project in Colón. REDA was the difference between keep dreaming and actually doing it."',
      t3name:  'Miguel Torres',
      t3role:  'First development · Colón',
    },

    cta: {
      label:   'Ideas that make you a better developer',
      sub:     'Every week: market analysis, financial strategies, real cases and exclusive resources for subscribers.',
      placeholder: 'Your email address',
      btn:     'Subscribe',
      trust:   'No spam. Real value only. Cancel anytime.',
    },

    footer: {
      tagline:    'The knowledge platform for real estate developers and investors who want to build with financial intelligence and solid structure.',
      products:   'Products',
      ebooks:     'Ebooks',
      course:     'REDM Course',
      excel:      'Excel Templates',
      contracts:  'Contracts Pack',
      mentoring:  'Mentoring',
      academy:    'Academy',
      about:      'About REDA',
      founder:    'The founder',
      blog:       'Blog',
      cases:      'Case studies',
      podcast:    'Podcast',
      support:    'Support',
      faq:        'FAQ',
      contact:    'Contact',
      privacy:    'Privacy policy',
      terms:      'Terms of use',
      refund:     'Refunds',
      copy:       '© 2025 Real Estate Developer Academy · redevacademy.com',
      designed:   'Designed for developers who build seriously.',
    },
  },

  /* ─────────────────────────────────────────────
     PORTUGUÊS
  ───────────────────────────────────────────── */
  pt: {
    lang: 'pt',
    dir: 'ltr',
    meta: {
      title: 'RED ACADEMY — Real Estate Developer Academy · Panamá & LATAM',
      description: 'Plataforma de conhecimento especializado para desenvolvedores imobiliários. Ebooks, simuladores e o Curso REDM para Panamá e América Latina.',
    },

    nav: {
      products:  'Produtos',
      curriculum:'Currículo',
      founder:   'Fundador',
      testimonials:'Depoimentos',
      tools:     'Ferramentas',
      cta:       'Ver Catálogo',
      signin:    'Entrar',
    },

    hero: {
      eyebrow:   'Real Estate Developer Academy',
      badge:     '5 ebooks + curso + simuladores',
      title1:    'O conhecimento',
      title2:    'que constrói',
      title3:    'projetos',
      titleEm:   'rentáveis',
      sub:       'Da análise de viabilidade ao fechamento de vendas. Metodologia real aplicada em desenvolvimentos no Panamá e LATAM — em ebooks profissionais, modelos e simuladores interativos.',
      pill1:     'Viabilidade',
      pill2:     'Orçamento',
      pill3:     'Financiamento',
      pill4:     'STR · Airbnb',
      pill5:     'Contratos',
      pill6:     'Curso REDM',
      cta1:      'Ver todos os ebooks',
      cta2:      'Curso REDM →',
      trust1:    'PDF + Excel incluídos',
      trust2:    'Acesso imediato',
      trust3:    'Dados reais do mercado',
    },

    stats: {
      s1num:   '+500', s1label: 'Alunos Ativos',
      s2num:   '12',   s2label: 'Ebooks & Cursos',
      s3num:   '$50M+',s3label: 'Em Projetos Desenvolvidos',
      s4num:   '8',    s4label: 'Países com Alunos',
    },

    manifesto: {
      label:   'Nossa Missão',
      quote:   '"O desenvolvedor que entende os números, controla o projeto."',
      p1:      'A maioria dos projetos imobiliários falha não por falta de terreno ou dinheiro, mas por falta de estrutura. Uma análise de custo ruim, uma projeção financeira incompleta ou uma negociação mal feita podem consumir meses de trabalho.',
      p2:      'A REDA nasceu para mudar isso. Condensamos mais de uma década de experiência real em desenvolvimentos residenciais, vilas de luxo e projetos mistos em recursos acionáveis que você pode aplicar a partir de hoje.',
      p3:      'Sem teoria. Sem casos genéricos. Metodologia comprovada no campo.',
    },

    pain: {
      label:   'Por que a REDA existe',
      title1:  'Os erros que',
      titleEm: 'custam milhões',
      e1title: 'Análise financeira deficiente',
      e1desc:  'Projetos que começam sem um modelo de fluxo de caixa sólido ficam descapitalizados antes da fase de vendas.',
      e2title: 'Custos de construção descontrolados',
      e2desc:  'O custo excessivo é a variável mais perigosa em qualquer desenvolvimento. Aprenda a estruturar orçamentos com contingências reais.',
      e3title: 'Estratégia comercial tardia',
      e3desc:  'Começar a vender quando o projeto já está construído é o erro clássico. Domine a comercialização antecipada.',
      e4title: 'Estrutura legal vulnerável',
      e4desc:  'Projetos sem holding patrimonial, sem contratos sólidos ou com títulos pendentes de registro são bombas-relógio.',
      e5title: 'Sem acesso a financiamento',
      e5desc:  'Os bancos financiam projetos bem documentados. Aprenda a montar dossiês bancários e avaliações.',
      e6title: 'Rentabilidade não quantificada',
      e6desc:  'Vender tudo e não saber quanto ganhou. A contabilidade de projeto e o cálculo correto do ROI são habilidades críticas.',
    },

    products: {
      label:   'Recursos',
      title1:  'Tudo o que você precisa',
      titleEm: 'para desenvolver',
      p1name:  'Análise de Viabilidade Imobiliária',
      p1desc:  'Metodologia completa para avaliar se um projeto vale a pena antes de investir um único dólar. Inclui modelos em Excel.',
      p1sub:   'PDF + Excel · 142 págs.',
      p2name:  'Orçamento de Construção Mestre',
      p2desc:  'Estruture capítulo por capítulo um orçamento real com materiais, mão de obra, imprevistos e contingências.',
      p2sub:   '14 capítulos · 120+ itens',
      p3name:  'Financiamento Bancário para Desenvolvedores',
      p3desc:  'Como montar o processo perfeito para crédito hipotecário ou linha rotativa. Documentos, índices e estratégias.',
      p3sub:   '10 bancos · Panamá 2025',
      p4name:  'Modelo Financeiro de Projetos STR',
      p4desc:  'Projeção de receitas, ocupação, custos operacionais e ROI para vilas e propriedades de aluguel de curto prazo em mercados turísticos.',
      p4sub:   'Airbnb · VRBO · 5 anos',
      p5name:  'Pack de Contratos para Desenvolvedores',
      p5desc:  'Contratos de promessa de compra e venda, acordos com empreiteiros, separações e protocolos de entrega prontos para usar.',
      p5sub:   '16 documentos · Word',
      p6name:  'Real Estate Developer Master – REDM',
      p6desc:  'O programa completo. Da seleção do terreno ao fechamento de vendas. 8 módulos com casos reais do Panamá e LATAM.',
      p6sub:   '8 módulos · Curso online',
      cta:     'Obter',
      ctaCourse: 'Ver Programa',
      tagEbook: 'Ebook',
      tagTemplate: 'Modelo',
      tagCourse: 'Curso Online',
      tagBestseller: 'Mais Vendido',
      tagNew: 'Novo',
    },

    curriculum: {
      label:   'Currículo REDM',
      title1:  'Construa seu',
      titleEm: 'primeiro desenvolvimento',
      sub:     'Um sistema completo de 8 módulos que cobre todo o processo de desenvolvimento imobiliário do zero à entrega.',
      m1: 'Módulo 1 · Fundamentos e Seleção de Terreno',
      m2: 'Módulo 2 · Análise de Viabilidade Avançada',
      m3: 'Módulo 3 · Projeto e Licenças',
      m4: 'Módulo 4 · Orçamento e Controle de Custos',
      m5: 'Módulo 5 · Financiamento Bancário',
      m6: 'Módulo 6 · Marketing e Pré-vendas',
      m7: 'Módulo 7 · Execução e Gestão de Obra',
      m8: 'Módulo 8 · Fechamento, Entrega e Rentabilidade Final',
      bonus: 'Bônus: Modelos Excel, contratos e simuladores',
      cta: 'Ver Programa Completo →',
    },

    founder: {
      label:   'O Fundador',
      name:    'Jorge Franco',
      role:    'CEO · Grupo Franco Carrera S.A.',
      bio1:    'Com mais de uma década desenvolvendo projetos residenciais, vilas de luxo e desenvolvimentos mistos em Bocas del Toro e Chiriquí, Jorge criou a REDA para trazer a metodologia real do campo para a sala de aula.',
      bio2:    'Mais de $2,3M em vendas residenciais concluídas. Fundador da Franco Inmobiliaria Panamá e co-fundador da APROBOCASDELTORO, a associação cívica de desenvolvimento provincial.',
      bio3:    '"Aprendi os erros mais caros nos meus próprios projetos. A REDA existe para que você não precise pagá-los."',
      cta:     'Ver Portfólio de Projetos →',
    },

    testimonials: {
      label:   'Depoimentos',
      title1:  'O que dizem',
      titleEm: 'nossos alunos',
      t1:      '"Apliquei o modelo de viabilidade do Módulo 2 no meu primeiro projeto e o banco aprovou o crédito na primeira apresentação. Não consigo acreditar na diferença que faz ter os números bem estruturados."',
      t1name:  'Carlos Mendoza',
      t1role:  'Desenvolvedor · Cidade do Panamá',
      t2:      '"O ebook de orçamento me poupou meses de trabalho e me salvou de um empreiteiro que queria me cobrar o dobro. Agora sei exatamente o que perguntar e o que esperar."',
      t2name:  'Daniela Ríos',
      t2role:  'Investidora · Chiriquí',
      t3:      '"Comecei sem saber nada sobre desenvolvimento imobiliário. Hoje estou fechando meu primeiro projeto de 8 unidades em Colón. A REDA foi a diferença entre continuar sonhando e realmente fazer."',
      t3name:  'Miguel Torres',
      t3role:  'Primeiro desenvolvimento · Colón',
    },

    cta: {
      label:   'Ideias que fazem de você um desenvolvedor melhor',
      sub:     'Toda semana: análise de mercado, estratégias financeiras, casos reais e recursos exclusivos para assinantes.',
      placeholder: 'Seu endereço de e-mail',
      btn:     'Assinar',
      trust:   'Sem spam. Só valor real. Cancelamento imediato.',
    },

    footer: {
      tagline:    'A plataforma de conhecimento para desenvolvedores e investidores imobiliários que querem construir com inteligência financeira e estrutura sólida.',
      products:   'Produtos',
      ebooks:     'Ebooks',
      course:     'Curso REDM',
      excel:      'Modelos Excel',
      contracts:  'Pack de Contratos',
      mentoring:  'Mentorias',
      academy:    'Academia',
      about:      'Sobre a REDA',
      founder:    'O fundador',
      blog:       'Blog',
      cases:      'Casos de estudo',
      podcast:    'Podcast',
      support:    'Suporte',
      faq:        'Perguntas frequentes',
      contact:    'Contato',
      privacy:    'Política de privacidade',
      terms:      'Termos de uso',
      refund:     'Devoluções',
      copy:       '© 2025 Real Estate Developer Academy · redevacademy.com',
      designed:   'Projetado para desenvolvedores que constroem com seriedade.',
    },
  },
};

/* ═══════════════════════════════════════════════════════════════
   ENGINE — Language switcher & DOM updater
═══════════════════════════════════════════════════════════════ */
const I18n = {
  current: 'es',

  // Detect language: URL > localStorage > browser
  detect() {
    const url  = new URLSearchParams(window.location.search).get('lang');
    const ls   = localStorage.getItem('reda_lang');
    const nav  = (navigator.language || '').slice(0,2);
    const lang = url || ls || (['es','en','pt'].includes(nav) ? nav : 'es');
    return ['es','en','pt'].includes(lang) ? lang : 'es';
  },

  // Get nested key: t('hero.title1')
  t(key) {
    const keys = key.split('.');
    let val = TRANSLATIONS[this.current];
    for (const k of keys) {
      if (!val) return key;
      val = val[k];
    }
    return val || key;
  },

  // Apply all translations to DOM
  apply() {
    // text content
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      const txt = this.t(key);
      if (txt && txt !== key) el.textContent = txt;
    });

    // innerHTML (allows bold etc)
    document.querySelectorAll('[data-i18n-html]').forEach(el => {
      const key = el.getAttribute('data-i18n-html');
      const txt = this.t(key);
      if (txt && txt !== key) el.innerHTML = txt;
    });

    // placeholder attribute
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const key = el.getAttribute('data-i18n-placeholder');
      const txt = this.t(key);
      if (txt && txt !== key) el.placeholder = txt;
    });

    // Update <html lang>
    document.documentElement.lang = this.current;

    // Update <title>
    const titleEl = document.querySelector('title');
    if (titleEl) titleEl.textContent = this.t('meta.title');

    // Update meta description
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.content = this.t('meta.description');

    // Update URL without reload
    const url = new URL(window.location.href);
    url.searchParams.set('lang', this.current);
    window.history.replaceState({}, '', url.toString());

    // Update switcher buttons
    document.querySelectorAll('.i18n-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.lang === this.current);
    });
  },

  // Switch to a language
  set(lang) {
    if (!TRANSLATIONS[lang]) return;
    this.current = lang;
    localStorage.setItem('reda_lang', lang);
    this.apply();
  },

  // Initialize
  init() {
    this.current = this.detect();
    this.injectSwitcher();
    this.apply();
  },

  // Inject language switcher into nav
  injectSwitcher() {
    const nav = document.querySelector('.nav-links') || document.querySelector('nav ul');
    if (!nav) return;

    const switcher = document.createElement('li');
    switcher.className = 'i18n-switcher';
    switcher.innerHTML = `
      <div class="i18n-wrap">
        <button class="i18n-btn ${this.current==='es'?'active':''}" data-lang="es" onclick="I18n.set('es')">
          <span class="i18n-flag">🇪🇸</span><span class="i18n-code">ES</span>
        </button>
        <button class="i18n-btn ${this.current==='en'?'active':''}" data-lang="en" onclick="I18n.set('en')">
          <span class="i18n-flag">🇺🇸</span><span class="i18n-code">EN</span>
        </button>
        <button class="i18n-btn ${this.current==='pt'?'active':''}" data-lang="pt" onclick="I18n.set('pt')">
          <span class="i18n-flag">🇧🇷</span><span class="i18n-code">PT</span>
        </button>
      </div>`;

    // Inject CSS
    if (!document.getElementById('i18n-css')) {
      const style = document.createElement('style');
      style.id = 'i18n-css';
      style.textContent = `
        .i18n-switcher { list-style: none; }
        .i18n-wrap {
          display: flex;
          align-items: center;
          gap: 2px;
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.1);
          padding: 3px;
        }
        .i18n-btn {
          display: flex;
          align-items: center;
          gap: 4px;
          padding: 4px 8px;
          background: transparent;
          border: none;
          cursor: pointer;
          font-family: inherit;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: .06em;
          color: rgba(255,255,255,0.4);
          transition: all .2s;
        }
        .i18n-btn:hover { color: rgba(255,255,255,0.8); }
        .i18n-btn.active {
          background: rgba(255,255,255,0.12);
          color: #fff;
        }
        .i18n-flag { font-size: 14px; line-height: 1; }
        .i18n-code { font-size: 10px; letter-spacing: .08em; }
        /* Light nav variant */
        .nav-light .i18n-wrap {
          background: rgba(0,0,0,0.05);
          border-color: rgba(0,0,0,0.1);
        }
        .nav-light .i18n-btn { color: rgba(0,0,0,0.4); }
        .nav-light .i18n-btn:hover { color: rgba(0,0,0,0.8); }
        .nav-light .i18n-btn.active {
          background: rgba(0,0,0,0.08);
          color: #000;
        }
      `;
      document.head.appendChild(style);
    }

    nav.appendChild(switcher);
  },
};

// Auto-init
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => I18n.init());
} else {
  I18n.init();
}

window.I18n = I18n;
