/**
 * RED ACADEMY — PayPal Checkout Modal
 * 
 * CONFIGURACIÓN (reemplazar con tus datos reales):
 * 1. Ve a developer.paypal.com → My Apps → Create App
 * 2. Copia el Client ID de LIVE (producción) o SANDBOX (pruebas)
 * 3. Reemplaza PAYPAL_CLIENT_ID abajo
 * 
 * PARA PRUEBAS: usa el Sandbox Client ID
 * PARA VENTAS REALES: usa el Live Client ID
 */

const PAYPAL_CLIENT_ID = 'TU_PAYPAL_CLIENT_ID_AQUI'; // ← Reemplazar

// ── STYLES ───────────────────────────────────────────────────
const CHECKOUT_CSS = `
#reda-checkout-overlay {
  position: fixed;
  inset: 0;
  background: rgba(8,8,8,0.85);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  opacity: 0;
  pointer-events: none;
  transition: opacity .3s;
}
#reda-checkout-overlay.open {
  opacity: 1;
  pointer-events: all;
}
#reda-checkout-box {
  background: #0D0D0D;
  border: 1px solid rgba(255,255,255,0.1);
  width: 100%;
  max-width: 480px;
  max-height: 92vh;
  overflow-y: auto;
  box-shadow: 0 32px 80px rgba(0,0,0,0.7);
  font-family: 'DM Sans', system-ui, sans-serif;
}
#reda-checkout-box::-webkit-scrollbar { width: 4px; }
#reda-checkout-box::-webkit-scrollbar-track { background: #111; }
#reda-checkout-box::-webkit-scrollbar-thumb { background: #333; border-radius: 2px; }

.ck-header {
  background: #080808;
  padding: 20px 24px;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  border-bottom: 1px solid rgba(255,255,255,0.06);
}
.ck-brand {
  font-size: 10px;
  letter-spacing: .18em;
  text-transform: uppercase;
  color: #C9943A;
  margin-bottom: 4px;
}
.ck-product-name {
  font-size: 16px;
  font-weight: 500;
  color: #fff;
  margin-bottom: 4px;
  font-family: 'Cormorant Garamond', 'DM Sans', serif;
  font-style: italic;
}
.ck-product-desc {
  font-size: 12px;
  color: rgba(255,255,255,0.35);
}
.ck-price {
  font-family: 'Cormorant Garamond', Georgia, serif;
  font-size: 36px;
  font-weight: 300;
  color: #C9943A;
  white-space: nowrap;
  margin-left: 16px;
}
.ck-price span { font-size: 14px; font-family: 'DM Sans', sans-serif; }
.ck-close {
  position: absolute;
  top: 14px;
  right: 16px;
  background: none;
  border: none;
  color: rgba(255,255,255,0.3);
  font-size: 22px;
  cursor: pointer;
  line-height: 1;
  transition: color .2s;
}
.ck-close:hover { color: #fff; }

.ck-body { padding: 24px; }

/* ── TABS ── */
.ck-tabs {
  display: flex;
  gap: 0;
  margin-bottom: 22px;
  border: 1px solid rgba(255,255,255,0.1);
}
.ck-tab {
  flex: 1;
  padding: 11px;
  background: transparent;
  border: none;
  color: rgba(255,255,255,0.4);
  font-size: 13px;
  font-weight: 500;
  letter-spacing: .04em;
  cursor: pointer;
  font-family: inherit;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  transition: all .2s;
}
.ck-tab:hover { color: rgba(255,255,255,0.7); background: rgba(255,255,255,0.04); }
.ck-tab.active { background: rgba(255,255,255,0.08); color: #fff; }
.ck-tab-icon { font-size: 16px; }

/* ── PAYPAL BUTTON CONTAINER ── */
#ck-paypal-container { min-height: 45px; }
.ck-paypal-note {
  text-align: center;
  font-size: 11px;
  color: rgba(255,255,255,0.25);
  margin-top: 10px;
}

/* ── CARD FORM ── */
.ck-panel { display: none; }
.ck-panel.active { display: block; }

.ck-field-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}
.ck-field {
  margin-bottom: 14px;
}
.ck-field label {
  display: block;
  font-size: 11px;
  font-weight: 500;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: rgba(255,255,255,0.4);
  margin-bottom: 6px;
}
.ck-field input,
.ck-hosted-field {
  width: 100%;
  height: 44px;
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.1);
  color: #fff;
  font-family: inherit;
  font-size: 14px;
  padding: 0 13px;
  transition: border-color .2s;
  box-sizing: border-box;
  border-radius: 0;
}
.ck-field input::placeholder { color: rgba(255,255,255,0.2); }
.ck-field input:focus { outline: none; border-color: #C9943A; }
.ck-hosted-field.focused { border-color: #C9943A !important; }
.ck-hosted-field.invalid  { border-color: #EF4444 !important; }
.ck-hosted-field.valid    { border-color: #10B981 !important; }

.ck-pay-btn {
  width: 100%;
  padding: 14px;
  background: #C9943A;
  color: #fff;
  border: none;
  font-size: 14px;
  font-weight: 600;
  letter-spacing: .06em;
  text-transform: uppercase;
  cursor: pointer;
  font-family: inherit;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: background .2s;
  margin-top: 6px;
}
.ck-pay-btn:hover:not(:disabled) { background: #B8832F; }
.ck-pay-btn:disabled { opacity: .6; cursor: not-allowed; }

.ck-divider {
  display: flex;
  align-items: center;
  gap: 12px;
  margin: 18px 0;
  font-size: 11px;
  color: rgba(255,255,255,0.2);
  letter-spacing: .06em;
  text-transform: uppercase;
}
.ck-divider::before,
.ck-divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background: rgba(255,255,255,0.08);
}

/* ── ERROR & SUCCESS ── */
.ck-error {
  background: rgba(239,68,68,0.1);
  border: 1px solid rgba(239,68,68,0.25);
  color: #FCA5A5;
  font-size: 13px;
  padding: 10px 14px;
  margin-bottom: 14px;
  display: none;
}
.ck-error.show { display: block; }

.ck-success {
  text-align: center;
  padding: 32px 24px;
  display: none;
}
.ck-success.show { display: block; }
.ck-success-icon { font-size: 48px; margin-bottom: 12px; }
.ck-success-title {
  font-family: 'Cormorant Garamond', Georgia, serif;
  font-size: 26px;
  font-weight: 300;
  color: #fff;
  margin-bottom: 8px;
}
.ck-success-sub { font-size: 14px; color: rgba(255,255,255,0.5); line-height: 1.6; margin-bottom: 20px; }
.ck-success-email {
  font-weight: 600;
  color: #C9943A;
}
.ck-download-btn {
  display: inline-block;
  padding: 12px 28px;
  background: #10B981;
  color: #fff;
  font-size: 13px;
  font-weight: 600;
  letter-spacing: .06em;
  text-transform: uppercase;
  text-decoration: none;
  transition: background .2s;
}
.ck-download-btn:hover { background: #0D9668; }

/* ── SPINNER ── */
.ck-spinner {
  width: 18px; height: 18px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin .7s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* ── SECURITY BADGE ── */
.ck-security {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding-top: 14px;
  border-top: 1px solid rgba(255,255,255,0.06);
  margin-top: 16px;
  font-size: 11px;
  color: rgba(255,255,255,0.2);
}
.ck-security-icon { font-size: 13px; }
`;

// ── HTML TEMPLATE ─────────────────────────────────────────────
const CHECKOUT_HTML = `
<div id="reda-checkout-overlay">
  <div id="reda-checkout-box">
    <button class="ck-close" onclick="Checkout.close()" title="Cerrar">✕</button>

    <!-- Header: product info + price -->
    <div class="ck-header">
      <div>
        <div class="ck-brand">RED ACADEMY</div>
        <div class="ck-product-name" id="ck-product-name">Producto</div>
        <div class="ck-product-desc" id="ck-product-desc">PDF · Acceso inmediato</div>
      </div>
      <div class="ck-price" id="ck-price">$<span id="ck-price-num">47</span></div>
    </div>

    <div class="ck-body">
      <!-- Error -->
      <div class="ck-error" id="ck-error"></div>

      <!-- Tabs -->
      <div class="ck-tabs" id="ck-tabs">
        <button class="ck-tab active" id="tab-paypal" onclick="Checkout.switchTab('paypal')">
          <span class="ck-tab-icon">🅿️</span> PayPal
        </button>
        <button class="ck-tab" id="tab-card" onclick="Checkout.switchTab('card')">
          <span class="ck-tab-icon">💳</span> Tarjeta
        </button>
      </div>

      <!-- PayPal Panel -->
      <div class="ck-panel active" id="panel-paypal">
        <div id="ck-paypal-container"></div>
        <p class="ck-paypal-note">Serás redirigido a PayPal de forma segura</p>
        <div class="ck-divider">o paga con tarjeta</div>
        <button class="ck-tab" style="width:100%;border:1px solid rgba(255,255,255,0.1);" onclick="Checkout.switchTab('card')">
          <span class="ck-tab-icon">💳</span> Pagar con Tarjeta →
        </button>
      </div>

      <!-- Card Panel -->
      <div class="ck-panel" id="panel-card">
        <div class="ck-field">
          <label>Nombre en la tarjeta</label>
          <input type="text" id="ck-card-name" placeholder="Jorge Franco" autocomplete="cc-name">
        </div>
        <div class="ck-field">
          <label>Número de tarjeta</label>
          <div class="ck-hosted-field" id="ck-card-number"></div>
        </div>
        <div class="ck-field-row">
          <div class="ck-field">
            <label>Vencimiento</label>
            <div class="ck-hosted-field" id="ck-expiry"></div>
          </div>
          <div class="ck-field">
            <label>CVV</label>
            <div class="ck-hosted-field" id="ck-cvv"></div>
          </div>
        </div>
        <div class="ck-field">
          <label>Email (para recibir el PDF)</label>
          <input type="email" id="ck-email" placeholder="tu@email.com" autocomplete="email">
        </div>
        <button class="ck-pay-btn" id="ck-pay-btn" onclick="Checkout.submitCard()">
          <span id="ck-btn-text">Pagar $<span id="ck-btn-price">47</span></span>
        </button>
        <div class="ck-divider">o</div>
        <button class="ck-tab" style="width:100%;border:1px solid rgba(255,255,255,0.1);" onclick="Checkout.switchTab('paypal')">
          <span class="ck-tab-icon">🅿️</span> Volver a PayPal
        </button>
      </div>

      <!-- Success State -->
      <div class="ck-success" id="ck-success">
        <div class="ck-success-icon">✅</div>
        <div class="ck-success-title">¡Pago completado!</div>
        <p class="ck-success-sub">
          Hemos enviado el PDF a<br>
          <span class="ck-success-email" id="ck-success-email"></span><br><br>
          También puedes descargarlo ahora mismo:
        </p>
        <a href="#" class="ck-download-btn" id="ck-download-link" target="_blank">
          ⬇ Descargar PDF ahora
        </a>
      </div>

      <!-- Security -->
      <div class="ck-security">
        <span class="ck-security-icon">🔒</span>
        Pago 100% seguro · Cifrado SSL · Powered by PayPal
      </div>
    </div>
  </div>
</div>`;

// ══════════════════════════════════════════════════════════════
// CHECKOUT ENGINE
// ══════════════════════════════════════════════════════════════
const Checkout = {
  currentProduct: null,
  paypalSDKLoaded: false,
  hostedFields: null,

  // ── INIT ────────────────────────────────────────────────────
  init() {
    // Inject CSS
    if (!document.getElementById('reda-ck-css')) {
      const style = document.createElement('style');
      style.id = 'reda-ck-css';
      style.textContent = CHECKOUT_CSS;
      document.head.appendChild(style);
    }
    // Inject HTML
    if (!document.getElementById('reda-checkout-overlay')) {
      document.body.insertAdjacentHTML('beforeend', CHECKOUT_HTML);
    }
    // Close on overlay click
    document.getElementById('reda-checkout-overlay').addEventListener('click', (e) => {
      if (e.target.id === 'reda-checkout-overlay') Checkout.close();
    });
    // Close on ESC
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') Checkout.close();
    });
  },

  // ── OPEN with product ────────────────────────────────────────
  open(productKey) {
    const lang = (window.I18n && window.I18n.current) || 'es';
    const product = window.PRODUCTS?.[productKey];
    if (!product) { console.error('Producto no encontrado:', productKey); return; }

    this.currentProduct = product;

    // Update header
    document.getElementById('ck-product-name').textContent = product.name[lang] || product.name.es;
    document.getElementById('ck-product-desc').textContent = product.desc[lang] || product.desc.es;
    document.getElementById('ck-price-num').textContent = product.price;
    document.getElementById('ck-btn-price').textContent = product.price;

    // Reset state
    this.resetState();

    // Show modal
    const overlay = document.getElementById('reda-checkout-overlay');
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';

    // Load PayPal SDK & render buttons
    this.loadPayPalSDK(() => {
      this.renderPayPalButton();
    });
  },

  // ── CLOSE ───────────────────────────────────────────────────
  close() {
    document.getElementById('reda-checkout-overlay').classList.remove('open');
    document.body.style.overflow = '';
  },

  // ── RESET STATE ─────────────────────────────────────────────
  resetState() {
    this.switchTab('paypal');
    document.getElementById('ck-error').classList.remove('show');
    document.getElementById('ck-success').classList.remove('show');
    document.getElementById('ck-tabs').style.display = '';
    document.getElementById('panel-paypal').classList.add('active');
    document.getElementById('panel-card').classList.remove('active');
    const cardName  = document.getElementById('ck-card-name');
    const email     = document.getElementById('ck-email');
    if (cardName) cardName.value = '';
    if (email)    email.value    = '';
  },

  // ── SWITCH TAB ──────────────────────────────────────────────
  switchTab(tab) {
    document.getElementById('tab-paypal').classList.toggle('active', tab === 'paypal');
    document.getElementById('tab-card').classList.toggle('active',   tab === 'card');
    document.getElementById('panel-paypal').classList.toggle('active', tab === 'paypal');
    document.getElementById('panel-card').classList.toggle('active',   tab === 'card');
    if (tab === 'card' && !this.hostedFields) {
      this.renderHostedFields();
    }
  },

  // ── LOAD PAYPAL SDK ─────────────────────────────────────────
  loadPayPalSDK(callback) {
    if (window.paypal) { callback(); return; }
    const script = document.createElement('script');
    script.src = `https://www.paypal.com/sdk/js?client-id=${PAYPAL_CLIENT_ID}&currency=USD&intent=capture&components=buttons,hosted-fields`;
    script.onload = callback;
    script.onerror = () => this.showError('Error cargando PayPal. Intenta con tarjeta.');
    document.head.appendChild(script);
  },

  // ── RENDER PAYPAL BUTTONS ───────────────────────────────────
  renderPayPalButton() {
    const container = document.getElementById('ck-paypal-container');
    if (!window.paypal || !container) return;
    container.innerHTML = '';

    window.paypal.Buttons({
      style: {
        layout: 'vertical',
        color:  'gold',
        shape:  'rect',
        label:  'paypal',
        height: 44,
      },

      // Create order — calls Netlify Function
      createOrder: async () => {
        const res = await fetch('/.netlify/functions/create-order', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({
            productId:   this.currentProduct.id,
            productName: this.currentProduct.name.es,
            amount:      this.currentProduct.price,
          }),
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        return data.orderID;
      },

      // Approved — capture order
      onApprove: async (data) => {
        const email = await this.promptEmail();
        const res = await fetch('/.netlify/functions/capture-order', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({
            orderID:   data.orderID,
            email:     email,
            productId: this.currentProduct.id,
            driveLink: this.currentProduct.driveLink,
            productName: this.currentProduct.name.es,
          }),
        });
        const result = await res.json();
        if (result.success) {
          this.showSuccess(email);
        } else {
          this.showError('Error al procesar el pago. Contacta a soporte.');
        }
      },

      onError: (err) => {
        console.error('PayPal error:', err);
        this.showError('Error en el pago de PayPal. Intenta de nuevo o usa tarjeta.');
      },

      onCancel: () => {
        // Do nothing — user cancelled
      },
    }).render('#ck-paypal-container');
  },

  // ── RENDER HOSTED CARD FIELDS ───────────────────────────────
  async renderHostedFields() {
    if (!window.paypal?.HostedFields) {
      // HostedFields not available — use simple form fallback
      return;
    }

    try {
      // First create an order to get the token
      const res = await fetch('/.netlify/functions/create-order', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({
          productId:   this.currentProduct.id,
          productName: this.currentProduct.name.es,
          amount:      this.currentProduct.price,
        }),
      });
      const data = await res.json();

      this.hostedFields = await window.paypal.HostedFields.render({
        createOrder: () => data.orderID,
        fields: {
          number: {
            selector:    '#ck-card-number',
            placeholder: '4111 1111 1111 1111',
          },
          expirationDate: {
            selector:    '#ck-expiry',
            placeholder: 'MM/YY',
          },
          cvv: {
            selector:    '#ck-cvv',
            placeholder: '123',
          },
        },
        styles: {
          input: {
            'font-size':   '14px',
            'color':       '#ffffff',
            'font-family': 'DM Sans, system-ui, sans-serif',
          },
          ':focus': { color: '#ffffff' },
          '.invalid': { color: '#FCA5A5' },
        },
      });

      // Style the hosted field containers
      ['ck-card-number','ck-expiry','ck-cvv'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.padding = '0';
      });

    } catch (e) {
      console.warn('HostedFields not available, using basic form');
    }
  },

  // ── SUBMIT CARD PAYMENT ─────────────────────────────────────
  async submitCard() {
    const email    = document.getElementById('ck-email')?.value?.trim();
    const cardName = document.getElementById('ck-card-name')?.value?.trim();

    if (!email || !email.includes('@')) {
      this.showError('Por favor ingresa un email válido para recibir tu PDF.');
      return;
    }

    const btn = document.getElementById('ck-pay-btn');
    const txt = document.getElementById('ck-btn-text');
    btn.disabled = true;
    txt.innerHTML = '<div class="ck-spinner"></div>';

    try {
      if (this.hostedFields) {
        // Submit via PayPal Hosted Fields
        const result = await this.hostedFields.submit({
          cardholderName: cardName,
          billingAddress: { streetAddress: '', locality: '', region: '', countryCodeAlpha2: 'PA' },
        });

        // Capture
        const res = await fetch('/.netlify/functions/capture-order', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({
            orderID:     result.orderId,
            email:       email,
            productId:   this.currentProduct.id,
            driveLink:   this.currentProduct.driveLink,
            productName: this.currentProduct.name.es,
          }),
        });
        const data = await res.json();
        if (data.success) {
          this.showSuccess(email);
        } else {
          this.showError(data.message || 'Error al procesar el pago.');
        }
      } else {
        // Fallback: redirect to PayPal
        this.showError('Por favor usa el botón de PayPal para completar el pago.');
      }
    } catch (err) {
      this.showError('Error al procesar la tarjeta. Verifica los datos e intenta de nuevo.');
    } finally {
      btn.disabled = false;
      txt.innerHTML = `Pagar $<span id="ck-btn-price">${this.currentProduct.price}</span>`;
    }
  },

  // ── PROMPT EMAIL (for PayPal flow) ───────────────────────────
  async promptEmail() {
    // Check if already entered in card tab
    const emailEl = document.getElementById('ck-email');
    if (emailEl?.value?.includes('@')) return emailEl.value.trim();

    // Ask via simple prompt
    const email = window.prompt('📧 ¿A qué email enviamos tu PDF?', '');
    return email || 'cliente@redacademy.com';
  },

  // ── SHOW SUCCESS ─────────────────────────────────────────────
  showSuccess(email) {
    // Hide tabs and panels
    document.getElementById('ck-tabs').style.display = 'none';
    document.getElementById('panel-paypal').classList.remove('active');
    document.getElementById('panel-card').classList.remove('active');
    document.getElementById('ck-error').classList.remove('show');

    // Set download link
    document.getElementById('ck-success-email').textContent = email;
    document.getElementById('ck-download-link').href = this.currentProduct.driveLink;

    // Show success panel
    document.getElementById('ck-success').classList.add('show');
  },

  // ── SHOW ERROR ───────────────────────────────────────────────
  showError(msg) {
    const el = document.getElementById('ck-error');
    el.textContent = '⚠ ' + msg;
    el.classList.add('show');
  },
};

// ── AUTO-INIT ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => Checkout.init());

// ── GLOBAL HELPER: open checkout from any button ──────────────
function buyProduct(productKey) {
  Checkout.open(productKey);
}

window.Checkout    = Checkout;
window.buyProduct  = buyProduct;
