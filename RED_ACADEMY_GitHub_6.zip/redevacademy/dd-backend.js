/**
 * DeveloperData.ai — Backend Module v1.0
 * Stack: Supabase (auth + DB) + Stripe (pagos)
 * Sin servidor propio — funciona con HTML estático
 *
 * CONFIGURACIÓN:
 * 1. Crear cuenta en supabase.com → New Project
 * 2. Copiar Project URL y anon key → reemplazar abajo
 * 3. Crear cuenta en stripe.com → copiar Publishable Key
 * 4. Ejecutar el SQL de setup en Supabase SQL Editor
 */

// ── CONFIGURACIÓN (reemplazar con tus keys reales) ────────────
const DD_CONFIG = {
  supabaseUrl:  'https://TU-PROYECTO.supabase.co',      // ← Supabase Project URL
  supabaseKey:  'TU-ANON-KEY-AQUI',                      // ← Supabase anon public key
  stripeKey:    'pk_live_TU-STRIPE-PUBLISHABLE-KEY',     // ← Stripe Publishable Key
  priceMonthly: 'price_TU-PRICE-ID-MONTHLY',            // ← Stripe Price ID mensual
  priceAnnual:  'price_TU-PRICE-ID-ANNUAL',             // ← Stripe Price ID anual
  appUrl:       'https://developerdata.ai',              // ← Tu dominio
};

// ── SQL PARA EJECUTAR EN SUPABASE (copiar en SQL Editor) ─────
/*
-- Tabla de suscripciones
CREATE TABLE subscriptions (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  stripe_customer_id text,
  stripe_subscription_id text,
  plan text DEFAULT 'explorer',        -- 'explorer' | 'pro' | 'academic'
  status text DEFAULT 'inactive',      -- 'active' | 'inactive' | 'canceled' | 'past_due'
  current_period_end timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Tabla de simulaciones guardadas
CREATE TABLE simulations (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL,      -- 'feasibility' | 'budget' | 'finance' | 'str'
  name text NOT NULL,
  data jsonb NOT NULL,
  created_at timestamp with time zone DEFAULT now()
);

-- Seguridad RLS (Row Level Security)
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE simulations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own subscription" ON subscriptions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users manage own simulations" ON simulations
  FOR ALL USING (auth.uid() = user_id);

-- Index de performance
CREATE INDEX idx_subscriptions_user ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_stripe ON subscriptions(stripe_subscription_id);
CREATE INDEX idx_simulations_user ON simulations(user_id);
*/

// ═══════════════════════════════════════════════════════════════
// MÓDULO DD (DeveloperData)
// ═══════════════════════════════════════════════════════════════
const DD = {
  _sb: null,        // Supabase client
  _stripe: null,    // Stripe instance
  user: null,       // Usuario actual
  sub: null,        // Suscripción actual
  isPro: false,     // Acceso PRO activo
  ready: false,     // Módulo inicializado

  // ── INIT ────────────────────────────────────────────────────
  async init() {
    // Cargar Supabase y Stripe desde CDN si no están cargados
    await DD._loadLibs();

    // Inicializar Supabase
    DD._sb = supabase.createClient(DD_CONFIG.supabaseUrl, DD_CONFIG.supabaseKey);

    // Inicializar Stripe
    if (window.Stripe) DD._stripe = Stripe(DD_CONFIG.stripeKey);

    // Recuperar sesión existente
    const { data: { session } } = await DD._sb.auth.getSession();
    if (session?.user) {
      DD.user = session.user;
      await DD._loadSubscription();
    }

    // Escuchar cambios de auth
    DD._sb.auth.onAuthStateChange(async (event, session) => {
      DD.user = session?.user || null;
      if (DD.user) {
        await DD._loadSubscription();
      } else {
        DD.sub = null;
        DD.isPro = false;
      }
      DD._updateUI();
      if (DD.onAuthChange) DD.onAuthChange(event, DD.user);
    });

    // Verificar si viene de un pago exitoso
    const params = new URLSearchParams(window.location.search);
    if (params.get('payment') === 'success') {
      await DD._handlePaymentSuccess();
    }

    DD.ready = true;
    DD._updateUI();
    if (DD.onReady) DD.onReady();
  },

  // ── LOAD LIBS ──────────────────────────────────────────────
  _loadLibs() {
    return new Promise(resolve => {
      let loaded = 0;
      const needed = 2;
      const done = () => { if (++loaded >= needed) resolve(); };

      // Supabase
      if (!window.supabase) {
        const s = document.createElement('script');
        s.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
        s.onload = done; document.head.appendChild(s);
      } else { done(); }

      // Stripe
      if (!window.Stripe) {
        const s = document.createElement('script');
        s.src = 'https://js.stripe.com/v3/';
        s.onload = done; document.head.appendChild(s);
      } else { done(); }
    });
  },

  // ── LOAD SUBSCRIPTION ──────────────────────────────────────
  async _loadSubscription() {
    if (!DD.user) return;
    const { data } = await DD._sb
      .from('subscriptions')
      .select('*')
      .eq('user_id', DD.user.id)
      .single();

    DD.sub = data;
    DD.isPro = data?.status === 'active' &&
               ['pro', 'academic'].includes(data?.plan) &&
               (data?.current_period_end ? new Date(data.current_period_end) > new Date() : true);
  },

  // ── AUTH: SIGN UP ──────────────────────────────────────────
  async signUp(email, password, name = '') {
    DD._showLoading('Creando cuenta...');
    const { data, error } = await DD._sb.auth.signUp({
      email, password,
      options: { data: { full_name: name } }
    });
    DD._hideLoading();
    if (error) throw error;

    // Crear registro de suscripción (plan explorer por defecto)
    if (data.user) {
      await DD._sb.from('subscriptions').insert({
        user_id: data.user.id,
        plan: 'explorer',
        status: 'inactive'
      });
    }
    return data;
  },

  // ── AUTH: SIGN IN ──────────────────────────────────────────
  async signIn(email, password) {
    DD._showLoading('Iniciando sesión...');
    const { data, error } = await DD._sb.auth.signInWithPassword({ email, password });
    DD._hideLoading();
    if (error) throw error;
    return data;
  },

  // ── AUTH: MAGIC LINK ────────────────────────────────────────
  async signInMagicLink(email) {
    const { error } = await DD._sb.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: DD_CONFIG.appUrl }
    });
    if (error) throw error;
  },

  // ── AUTH: GOOGLE OAUTH ──────────────────────────────────────
  async signInWithGoogle() {
    const { error } = await DD._sb.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: DD_CONFIG.appUrl }
    });
    if (error) throw error;
  },

  // ── AUTH: SIGN OUT ─────────────────────────────────────────
  async signOut() {
    await DD._sb.auth.signOut();
    DD.user = null; DD.sub = null; DD.isPro = false;
    DD._updateUI();
  },

  // ── STRIPE: SUBSCRIBE ──────────────────────────────────────
  async subscribe(plan = 'monthly') {
    if (!DD.user) { DD.showAuthModal('signup'); return; }

    DD._showLoading('Preparando pago...');
    const priceId = plan === 'annual' ? DD_CONFIG.priceAnnual : DD_CONFIG.priceMonthly;

    try {
      // Llamar a Supabase Edge Function que crea la sesión de Stripe
      const { data, error } = await DD._sb.functions.invoke('create-checkout-session', {
        body: {
          priceId,
          userId: DD.user.id,
          email: DD.user.email,
          successUrl: `${DD_CONFIG.appUrl}?payment=success`,
          cancelUrl: `${DD_CONFIG.appUrl}?payment=canceled`,
        }
      });

      DD._hideLoading();
      if (error) throw error;

      // Redirigir a Stripe Checkout
      window.location.href = data.url;
    } catch (e) {
      DD._hideLoading();
      DD._showError('Error al procesar el pago. Intenta de nuevo.');
      console.error(e);
    }
  },

  // ── STRIPE: MANAGE (portal de cliente) ────────────────────
  async manageSubscription() {
    if (!DD.user || !DD.sub?.stripe_customer_id) return;

    DD._showLoading('Abriendo portal...');
    const { data, error } = await DD._sb.functions.invoke('create-portal-session', {
      body: {
        customerId: DD.sub.stripe_customer_id,
        returnUrl: DD_CONFIG.appUrl
      }
    });
    DD._hideLoading();
    if (!error && data?.url) window.location.href = data.url;
  },

  // ── PAYMENT SUCCESS HANDLER ────────────────────────────────
  async _handlePaymentSuccess() {
    DD._showSuccess('¡Suscripción activada! Bienvenido a PRO.');
    await DD._loadSubscription();
    DD._updateUI();
    // Limpiar URL
    window.history.replaceState({}, '', window.location.pathname);
  },

  // ── SIMULATIONS: SAVE ─────────────────────────────────────
  async saveSimulation(type, name, data) {
    if (!DD.user) { DD.showAuthModal('signup'); return null; }

    const { data: saved, error } = await DD._sb
      .from('simulations')
      .insert({ user_id: DD.user.id, type, name, data })
      .select().single();

    if (error) throw error;
    return saved;
  },

  // ── SIMULATIONS: LOAD ─────────────────────────────────────
  async loadSimulations(type = null) {
    if (!DD.user) return [];

    let query = DD._sb.from('simulations')
      .select('*')
      .eq('user_id', DD.user.id)
      .order('created_at', { ascending: false });

    if (type) query = query.eq('type', type);

    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  },

  // ── UI: UPDATE ALL ELEMENTS ───────────────────────────────
  _updateUI() {
    // Elementos visibles solo con PRO
    document.querySelectorAll('[data-pro]').forEach(el => {
      if (DD.isPro) {
        el.style.filter = 'none';
        el.style.pointerEvents = 'auto';
        el.style.userSelect = 'auto';
      } else {
        el.style.filter = 'blur(7px)';
        el.style.pointerEvents = 'none';
        el.style.userSelect = 'none';
      }
    });

    // Overlays de paywall
    document.querySelectorAll('[data-paywall-overlay]').forEach(el => {
      el.style.display = DD.isPro ? 'none' : 'flex';
    });

    // Elementos visibles solo para usuarios autenticados
    document.querySelectorAll('[data-auth-only]').forEach(el => {
      el.style.display = DD.user ? (el.dataset.display || 'block') : 'none';
    });

    // Elementos visibles solo para visitantes (no autenticados)
    document.querySelectorAll('[data-guest-only]').forEach(el => {
      el.style.display = DD.user ? 'none' : (el.dataset.display || 'block');
    });

    // Nombre del usuario
    document.querySelectorAll('[data-user-name]').forEach(el => {
      el.textContent = DD.user?.user_metadata?.full_name ||
                       DD.user?.email?.split('@')[0] || '';
    });

    // Plan del usuario
    document.querySelectorAll('[data-user-plan]').forEach(el => {
      el.textContent = DD.isPro ? 'PRO' : 'Explorer';
    });

    // Botones de suscripción
    document.querySelectorAll('[data-subscribe-btn]').forEach(btn => {
      if (DD.isPro) {
        btn.textContent = 'Gestionar suscripción';
        btn.onclick = () => DD.manageSubscription();
      } else if (DD.user) {
        btn.textContent = 'Suscribirse a PRO →';
        btn.onclick = () => DD.showPaywallModal();
      } else {
        btn.textContent = 'Crear cuenta gratis →';
        btn.onclick = () => DD.showAuthModal('signup');
      }
    });
  },

  // ── MODAL: AUTH (login / signup) ──────────────────────────
  showAuthModal(mode = 'signin') {
    DD._removeModals();
    const modal = document.createElement('div');
    modal.id = 'dd-auth-modal';
    modal.innerHTML = `
    <div style="position:fixed;inset:0;background:rgba(4,5,15,0.85);backdrop-filter:blur(8px);z-index:10000;display:flex;align-items:center;justify-content:center;padding:20px;">
      <div style="background:#fff;max-width:420px;width:100%;border-radius:8px;overflow:hidden;box-shadow:0 40px 100px rgba(0,0,0,.5);">
        <div style="background:#04050F;padding:28px 32px;position:relative;">
          <button onclick="document.getElementById('dd-auth-modal').remove()" style="position:absolute;top:14px;right:18px;background:none;border:none;color:rgba(255,255,255,0.4);font-size:20px;cursor:pointer;">✕</button>
          <div style="font-size:10px;letter-spacing:.16em;text-transform:uppercase;color:#00D4FF;margin-bottom:6px;">DeveloperData.ai</div>
          <h3 style="font-family:'Syne',sans-serif;font-size:22px;color:#fff;font-weight:700;" id="dd-modal-title">${mode === 'signup' ? 'Crear cuenta gratis' : 'Iniciar sesión'}</h3>
          <p style="font-size:13px;color:rgba(255,255,255,0.5);margin-top:4px;">Accede a los simuladores y guarda tus proyectos</p>
        </div>
        <div style="padding:28px 32px;">
          <div id="dd-auth-error" style="display:none;background:#FEF2F2;border:1px solid #FECACA;color:#DC2626;padding:10px 14px;font-size:13px;margin-bottom:16px;border-radius:4px;"></div>
          ${mode === 'signup' ? '<div style="margin-bottom:14px;"><label style="font-size:11px;font-weight:500;color:#6B7280;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.04em;">Nombre completo</label><input id="dd-name" type="text" placeholder="Jorge Franco" style="width:100%;padding:10px 12px;border:1px solid #E5E7EB;font-family:inherit;font-size:14px;outline:none;border-radius:4px;"/></div>' : ''}
          <div style="margin-bottom:14px;"><label style="font-size:11px;font-weight:500;color:#6B7280;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.04em;">Email</label><input id="dd-email" type="email" placeholder="tu@email.com" style="width:100%;padding:10px 12px;border:1px solid #E5E7EB;font-family:inherit;font-size:14px;outline:none;border-radius:4px;"/></div>
          <div style="margin-bottom:20px;"><label style="font-size:11px;font-weight:500;color:#6B7280;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.04em;">Contraseña</label><input id="dd-password" type="password" placeholder="Mínimo 6 caracteres" style="width:100%;padding:10px 12px;border:1px solid #E5E7EB;font-family:inherit;font-size:14px;outline:none;border-radius:4px;"/></div>
          <button id="dd-auth-btn" style="width:100%;padding:13px;background:#04050F;color:#fff;border:none;font-size:13px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;font-family:inherit;border-radius:4px;" onclick="DD._handleAuth('${mode}')">
            ${mode === 'signup' ? 'Crear cuenta gratis' : 'Iniciar sesión'} →
          </button>
          <div style="text-align:center;margin-top:14px;font-size:12px;color:#9CA3AF;">
            ${mode === 'signup' ? 'Ya tienes cuenta? <a href="#" onclick="DD.showAuthModal(\'signin\');return false;" style="color:#04050F;font-weight:500;">Iniciar sesión</a>' : 'No tienes cuenta? <a href="#" onclick="DD.showAuthModal(\'signup\');return false;" style="color:#04050F;font-weight:500;">Crear cuenta gratis</a>'}
          </div>
          <div style="display:flex;align-items:center;gap:12px;margin:16px 0;">
            <div style="flex:1;height:1px;background:#E5E7EB;"></div>
            <span style="font-size:11px;color:#9CA3AF;">o continúa con</span>
            <div style="flex:1;height:1px;background:#E5E7EB;"></div>
          </div>
          <button onclick="DD.signInWithGoogle()" style="width:100%;padding:11px;background:#fff;border:1px solid #E5E7EB;color:#374151;font-size:13px;font-weight:500;cursor:pointer;font-family:inherit;border-radius:4px;display:flex;align-items:center;justify-content:center;gap:8px;">
            <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Google
          </button>
        </div>
      </div>
    </div>`;
    document.body.appendChild(modal);
    setTimeout(() => document.getElementById('dd-email')?.focus(), 100);
  },

  async _handleAuth(mode) {
    const btn = document.getElementById('dd-auth-btn');
    const errEl = document.getElementById('dd-auth-error');
    const email = document.getElementById('dd-email')?.value?.trim();
    const password = document.getElementById('dd-password')?.value;
    const name = document.getElementById('dd-name')?.value?.trim();

    if (!email || !password) { DD._showModalError('Completa todos los campos'); return; }
    if (password.length < 6) { DD._showModalError('Contraseña mínimo 6 caracteres'); return; }

    btn.textContent = 'Cargando...'; btn.disabled = true;
    try {
      if (mode === 'signup') await DD.signUp(email, password, name);
      else await DD.signIn(email, password);
      DD._removeModals();
    } catch (e) {
      btn.textContent = mode === 'signup' ? 'Crear cuenta gratis →' : 'Iniciar sesión →';
      btn.disabled = false;
      const msg = e.message?.includes('already registered') ? 'Este email ya está registrado. ¿Quieres iniciar sesión?' :
                  e.message?.includes('Invalid login') ? 'Email o contraseña incorrectos.' : e.message;
      DD._showModalError(msg);
    }
  },

  _showModalError(msg) {
    const el = document.getElementById('dd-auth-error');
    if (el) { el.textContent = msg; el.style.display = 'block'; }
  },

  // ── MODAL: PAYWALL ────────────────────────────────────────
  showPaywallModal(feature = '') {
    if (!DD.user) { DD.showAuthModal('signup'); return; }
    DD._removeModals();

    const modal = document.createElement('div');
    modal.id = 'dd-paywall-modal';
    modal.innerHTML = `
    <div style="position:fixed;inset:0;background:rgba(4,5,15,0.85);backdrop-filter:blur(8px);z-index:10000;display:flex;align-items:center;justify-content:center;padding:20px;">
      <div style="background:#fff;max-width:460px;width:100%;border-radius:8px;overflow:hidden;box-shadow:0 40px 100px rgba(0,0,0,.5);">
        <div style="background:#04050F;padding:28px 32px;position:relative;">
          <button onclick="document.getElementById('dd-paywall-modal').remove()" style="position:absolute;top:14px;right:18px;background:none;border:none;color:rgba(255,255,255,0.4);font-size:20px;cursor:pointer;">✕</button>
          <div style="font-size:10px;letter-spacing:.16em;text-transform:uppercase;color:#00D4FF;margin-bottom:6px;">DeveloperData.ai PRO</div>
          <h3 style="font-family:'Syne',sans-serif;font-size:24px;color:#fff;font-weight:700;">Desbloquea el análisis completo</h3>
          <p style="font-size:13px;color:rgba(255,255,255,0.5);margin-top:6px;">TIR, VPN, escenarios, sensibilidad, todos los bancos y export PDF</p>
        </div>
        <div style="padding:24px 32px;">
          <div style="display:flex;gap:0;border:1px solid #E5E7EB;margin-bottom:20px;">
            <button id="pw-monthly" onclick="DD._setPWPlan('monthly')" style="flex:1;padding:10px;font-size:12px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;border:none;background:#04050F;color:#fff;font-family:inherit;">Mensual — $29</button>
            <button id="pw-annual" onclick="DD._setPWPlan('annual')" style="flex:1;padding:10px;font-size:12px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;border:none;background:transparent;color:#6B7280;font-family:inherit;">Anual — $19/mes <span style="color:#10B981;font-size:10px;">−33%</span></button>
          </div>
          <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:20px;">
            ${['TIR anualizada y VPN al WACC seleccionado','3 escenarios: pesimista, base y optimista','Matriz de sensibilidad precio × costo','Decisión GO/NO-GO con 5 filtros automáticos','Los 10 bancos de Panamá comparados','14 capítulos del presupuesto completo','Exportar análisis a PDF','Cancela cuando quieras · Garantía 14 días'].map(f=>`
            <div style="display:flex;align-items:center;gap:10px;font-size:13px;color:#374151;">
              <span style="color:#10B981;font-weight:700;flex-shrink:0;">✓</span>${f}
            </div>`).join('')}
          </div>
          <button onclick="DD.subscribe(DD._pwPlan||'monthly')" style="width:100%;padding:14px;background:linear-gradient(135deg,#00A8CC,#6366F1);color:#fff;border:none;font-size:13px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;font-family:inherit;border-radius:4px;">
            Suscribirse a PRO →
          </button>
          <div style="text-align:center;margin-top:10px;font-size:12px;color:#9CA3AF;">
            O <a href="#" onclick="document.getElementById('dd-paywall-modal').remove();return false;" style="color:#374151;font-weight:500;">continuar gratis con resultados básicos</a>
          </div>
        </div>
      </div>
    </div>`;
    document.body.appendChild(modal);
    DD._pwPlan = 'monthly';
  },

  _pwPlan: 'monthly',
  _setPWPlan(plan) {
    DD._pwPlan = plan;
    document.getElementById('pw-monthly').style.background = plan === 'monthly' ? '#04050F' : 'transparent';
    document.getElementById('pw-monthly').style.color = plan === 'monthly' ? '#fff' : '#6B7280';
    document.getElementById('pw-annual').style.background = plan === 'annual' ? '#04050F' : 'transparent';
    document.getElementById('pw-annual').style.color = plan === 'annual' ? '#fff' : '#6B7280';
  },

  // ── MODAL: USER MENU ─────────────────────────────────────
  showUserMenu(anchorEl) {
    DD._removeMenus();
    if (!DD.user) { DD.showAuthModal('signin'); return; }

    const rect = anchorEl?.getBoundingClientRect();
    const menu = document.createElement('div');
    menu.id = 'dd-user-menu';
    menu.innerHTML = `
    <div style="position:fixed;top:${(rect?.bottom||60)+8}px;right:${window.innerWidth-(rect?.right||300)}px;background:#fff;border:1px solid #E5E7EB;padding:8px;min-width:220px;box-shadow:0 10px 40px rgba(0,0,0,.15);z-index:9999;border-radius:6px;">
      <div style="padding:10px 12px;border-bottom:1px solid #F3F4F6;margin-bottom:4px;">
        <div style="font-size:13px;font-weight:500;color:#111827;">${DD.user.user_metadata?.full_name || DD.user.email}</div>
        <div style="font-size:11px;color:#6B7280;margin-top:2px;">Plan: <span style="color:${DD.isPro?'#10B981':'#6B7280'};font-weight:600;">${DD.isPro?'PRO':'Explorer'}</span></div>
      </div>
      ${DD.isPro
        ? `<button onclick="DD.manageSubscription()" style="width:100%;text-align:left;padding:9px 12px;font-size:13px;cursor:pointer;border:none;background:none;font-family:inherit;color:#374151;border-radius:4px;" onmouseover="this.style.background='#F9FAFB'" onmouseout="this.style.background='none'">⚙ Gestionar suscripción</button>`
        : `<button onclick="DD._removeMenus();DD.showPaywallModal()" style="width:100%;text-align:left;padding:9px 12px;font-size:13px;cursor:pointer;border:none;background:#EFF6FF;font-family:inherit;color:#1D4ED8;font-weight:500;border-radius:4px;">⚡ Actualizar a PRO →</button>`
      }
      <button onclick="DD.signOut();DD._removeMenus()" style="width:100%;text-align:left;padding:9px 12px;font-size:13px;cursor:pointer;border:none;background:none;font-family:inherit;color:#6B7280;margin-top:2px;border-radius:4px;" onmouseover="this.style.background='#F9FAFB'" onmouseout="this.style.background='none'">
        Cerrar sesión
      </button>
    </div>`;
    document.body.appendChild(menu);
    setTimeout(() => document.addEventListener('click', DD._closeMenuOnClick, { once: true }), 100);
  },

  _closeMenuOnClick(e) { if (!document.getElementById('dd-user-menu')?.contains(e.target)) DD._removeMenus(); },
  _removeMenus() { document.getElementById('dd-user-menu')?.remove(); },
  _removeModals() { document.getElementById('dd-auth-modal')?.remove(); document.getElementById('dd-paywall-modal')?.remove(); },

  // ── LOADING / TOAST ───────────────────────────────────────
  _showLoading(msg = 'Cargando...') {
    let el = document.getElementById('dd-loading');
    if (!el) {
      el = document.createElement('div');
      el.id = 'dd-loading';
      el.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#04050F;color:#fff;padding:10px 20px;font-size:13px;z-index:99999;border-radius:4px;display:flex;align-items:center;gap:10px;';
      document.body.appendChild(el);
    }
    el.innerHTML = `<div style="width:14px;height:14px;border:2px solid rgba(255,255,255,0.3);border-top-color:#00D4FF;border-radius:50%;animation:ddspin 0.7s linear infinite;"></div>${msg}`;
    if (!document.getElementById('dd-spin-style')) {
      const s = document.createElement('style');
      s.id = 'dd-spin-style';
      s.textContent = '@keyframes ddspin{to{transform:rotate(360deg)}}';
      document.head.appendChild(s);
    }
  },
  _hideLoading() { document.getElementById('dd-loading')?.remove(); },
  _showSuccess(msg) {
    const el = document.createElement('div');
    el.style.cssText = 'position:fixed;bottom:20px;right:20px;background:#10B981;color:#fff;padding:12px 20px;font-size:13px;z-index:99999;border-radius:4px;box-shadow:0 4px 20px rgba(16,185,129,0.3);';
    el.textContent = '✓ ' + msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 4000);
  },
  _showError(msg) {
    const el = document.createElement('div');
    el.style.cssText = 'position:fixed;bottom:20px;right:20px;background:#EF4444;color:#fff;padding:12px 20px;font-size:13px;z-index:99999;border-radius:4px;';
    el.textContent = '✗ ' + msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 5000);
  },
};

// Auto-inicializar al cargar el DOM
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => DD.init());
} else {
  DD.init();
}

// Exponer globalmente
window.DD = DD;
